-- PKG_AUDIT
CREATE OR REPLACE PACKAGE PKG_AUDIT AS
  PROCEDURE LOG_EVENT(p_obj_name IN VARCHAR2, p_obj_id IN NUMBER, p_operation IN VARCHAR2, p_details IN VARCHAR2);
END PKG_AUDIT;
/
CREATE OR REPLACE PACKAGE BODY PKG_AUDIT AS
  PROCEDURE LOG_EVENT(p_obj_name IN VARCHAR2, p_obj_id IN NUMBER, p_operation IN VARCHAR2, p_details IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO APP_AUDIT_LOG(OBJ_NAME, OBJ_ID, OPERATION, DETAILS)
    VALUES (p_obj_name, p_obj_id, p_operation, SUBSTR(p_details,1,4000));
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;
END PKG_AUDIT;
/

-- PKG_BILLING
CREATE OR REPLACE PACKAGE PKG_BILLING AS
  FUNCTION VALIDATE_ORDER(p_order_id IN NUMBER) RETURN NUMBER; -- 1 ok, 0 fail
  PROCEDURE SETTLE_ORDER(p_order_id IN NUMBER);
  PROCEDURE PROCESS_BATCH(p_from_ts IN TIMESTAMP, p_to_ts IN TIMESTAMP, p_limit IN NUMBER);
  FUNCTION CLAIM_JOB(p_worker IN VARCHAR2) RETURN NUMBER; -- zwraca ORDER_ID albo NULL (0)
  PROCEDURE COMPLETE_JOB(p_order_id IN NUMBER, p_ok IN NUMBER, p_msg IN VARCHAR2);
END PKG_BILLING;
/
CREATE OR REPLACE PACKAGE BODY PKG_BILLING AS

  FUNCTION VALIDATE_ORDER(p_order_id IN NUMBER) RETURN NUMBER IS
    v_status APP_ORDER.STATUS%TYPE;
    v_items NUMBER;
    v_bad NUMBER;
  BEGIN
    SELECT STATUS INTO v_status FROM APP_ORDER WHERE ORDER_ID = p_order_id;

    SELECT COUNT(*) INTO v_items FROM APP_ORDER_ITEM WHERE ORDER_ID = p_order_id;
    IF v_items = 0 THEN
      RETURN 0;
    END IF;

    SELECT COUNT(*) INTO v_bad
    FROM APP_ORDER_ITEM
    WHERE ORDER_ID = p_order_id
      AND (QTY <= 0 OR UNIT_PRICE < 0);

    IF v_bad > 0 THEN
      RETURN 0;
    END IF;

    IF v_status NOT IN ('NEW','PAID') THEN
      RETURN 0;
    END IF;

    RETURN 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 0;
    WHEN OTHERS THEN
      RETURN 0;
  END;

  PROCEDURE SETTLE_ORDER(p_order_id IN NUMBER) IS
    v_ok NUMBER;
    v_customer_id NUMBER;
    v_net NUMBER(14,2);
    v_tax NUMBER(14,2);
    v_gross NUMBER(14,2);
    v_invoice_id NUMBER;
    v_tax_rate CONSTANT NUMBER(5,2) := 0.23;
  BEGIN
    v_ok := VALIDATE_ORDER(p_order_id);
    IF v_ok = 0 THEN
      PKG_AUDIT.LOG_EVENT('APP_ORDER', p_order_id, 'SETTLE_FAIL', 'Validation failed');
      RAISE_APPLICATION_ERROR(-20001, 'Order validation failed');
    END IF;

    SELECT CUSTOMER_ID INTO v_customer_id FROM APP_ORDER WHERE ORDER_ID = p_order_id;

    SELECT NVL(SUM(QTY * UNIT_PRICE),0)
      INTO v_net
    FROM APP_ORDER_ITEM
    WHERE ORDER_ID = p_order_id;

    v_tax := ROUND(v_net * v_tax_rate, 2);
    v_gross := v_net + v_tax;

    v_invoice_id := SEQ_INVOICE.NEXTVAL;
    INSERT INTO APP_INVOICE(INVOICE_ID, ORDER_ID, CUSTOMER_ID, NET_AMOUNT, TAX_AMOUNT, GROSS_AMOUNT)
    VALUES (v_invoice_id, p_order_id, v_customer_id, v_net, v_tax, v_gross);

    FOR r IN (
      SELECT PRODUCT_ID, QTY, UNIT_PRICE
      FROM APP_ORDER_ITEM
      WHERE ORDER_ID = p_order_id
    ) LOOP
      INSERT INTO APP_INVOICE_ITEM(
        INVOICE_ITEM_ID, INVOICE_ID, PRODUCT_ID, QTY,
        NET_PRICE, TAX_RATE, TAX_VALUE, GROSS_PRICE
      )
      VALUES (
        SEQ_INVOICE_ITEM.NEXTVAL, v_invoice_id, r.PRODUCT_ID, r.QTY,
        ROUND(r.UNIT_PRICE,2),
        v_tax_rate,
        ROUND(r.UNIT_PRICE * v_tax_rate, 2),
        ROUND(r.UNIT_PRICE * (1 + v_tax_rate), 2)
      );
    END LOOP;

    UPDATE APP_ORDER SET STATUS = 'PAID' WHERE ORDER_ID = p_order_id;

    PKG_AUDIT.LOG_EVENT('APP_ORDER', p_order_id, 'SETTLED', 'Invoice '||v_invoice_id||' gross='||v_gross);
  END;

  PROCEDURE PROCESS_BATCH(p_from_ts IN TIMESTAMP, p_to_ts IN TIMESTAMP, p_limit IN NUMBER) IS
    v_done NUMBER := 0;
  BEGIN
    FOR r IN (
      SELECT ORDER_ID
      FROM APP_ORDER
      WHERE ORDER_TS BETWEEN p_from_ts AND p_to_ts
      ORDER BY ORDER_TS
      FETCH FIRST p_limit ROWS ONLY
    ) LOOP
      BEGIN
        SETTLE_ORDER(r.ORDER_ID);
        v_done := v_done + 1;
      EXCEPTION
        WHEN OTHERS THEN
            DECLARE
              v_err VARCHAR2(4000);
            BEGIN
              v_err := SUBSTR(SQLERRM, 1, 4000);
              INSERT INTO APP_REJECTED_ROWS(SRC, ROW_PAYLOAD, REASON)
              VALUES ('BILLING', TO_CLOB('ORDER_ID=' || TO_CHAR(r.ORDER_ID)), v_err);
            END;
      END;


    END LOOP;

    PKG_AUDIT.LOG_EVENT('PKG_BILLING', NULL, 'BATCH', 'Processed='||v_done);
  END;

  FUNCTION CLAIM_JOB(p_worker IN VARCHAR2) RETURN NUMBER IS
  v_job_id   NUMBER;
  v_order_id NUMBER;
BEGIN
  SELECT MIN(job_id)
    INTO v_job_id
  FROM app_job
  WHERE status = 'QUEUED';

  IF v_job_id IS NULL THEN
    RETURN 0;
  END IF;

  UPDATE app_job
  SET status    = 'IN_PROGRESS',
      locked_by = p_worker,
      locked_at = SYSTIMESTAMP
  WHERE job_id = v_job_id
    AND status = 'QUEUED'
  RETURNING order_id INTO v_order_id;

  IF SQL%ROWCOUNT = 0 THEN
    ROLLBACK;
    RETURN 0;
  END IF;

  COMMIT;
  RETURN v_order_id;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN 0;
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN 0;
END;




  PROCEDURE COMPLETE_JOB(p_order_id IN NUMBER, p_ok IN NUMBER, p_msg IN VARCHAR2) IS
  BEGIN
    UPDATE APP_JOB
      SET STATUS = CASE WHEN p_ok=1 THEN 'DONE' ELSE 'FAILED' END
    WHERE ORDER_ID = p_order_id;

    PKG_AUDIT.LOG_EVENT('APP_JOB', p_order_id, 'COMPLETE', SUBSTR(p_msg,1,4000));
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;

END PKG_BILLING;
/
