import os
import time
import socket
import random
import oracledb

DB_HOST = os.getenv("DB_HOST", "oracle")
DB_PORT = int(os.getenv("DB_PORT", "1521"))
DB_SERVICE = os.getenv("DB_SERVICE", "XEPDB1")
DB_USER = os.getenv("DB_USER", "APP")
DB_PASSWORD = os.getenv("DB_PASSWORD", "app_pass")

WORKER = socket.gethostname()

def dsn():
    return oracledb.makedsn(DB_HOST, DB_PORT, service_name=DB_SERVICE)

def connect():
    return oracledb.connect(user=DB_USER, password=DB_PASSWORD, dsn=dsn())

def seed(conn):
    cur = conn.cursor()

    for i in range(1, 6):
        email = f"user{i}@example.com"
        name = f"User {i}"
        cur.execute("""
            MERGE INTO APP_CUSTOMER c
            USING (SELECT :id AS id, :email AS email, :name AS name FROM dual) s
            ON (c.customer_id=s.id)
            WHEN NOT MATCHED THEN
              INSERT (customer_id,email,full_name) VALUES (s.id,s.email,s.name)
        """, id=i, email=email, name=name)

    products = [
        (1, "SKU-001", "Keyboard", 120.00),
        (2, "SKU-002", "Mouse", 45.00),
        (3, "SKU-003", "Monitor", 900.00),
        (4, "SKU-004", "USB-C Cable", 25.00),
        (5, "SKU-005", "Headset", 260.00),
    ]
    for pid, sku, name, price in products:
        cur.execute("""
            MERGE INTO APP_PRODUCT p
            USING (SELECT :id AS id, :sku AS sku, :name AS name, :price AS price FROM dual) s
            ON (p.product_id=s.id)
            WHEN NOT MATCHED THEN
              INSERT (product_id,sku,name,price) VALUES (s.id,s.sku,s.name,s.price)
        """, id=pid, sku=sku, name=name, price=price)

    conn.commit()

def create_orders_and_jobs(conn, n_orders=20):
    cur = conn.cursor()

    for _ in range(n_orders):
        order_id = cur.var(int)
        cur.execute("SELECT SEQ_ORDER.NEXTVAL FROM dual")
        oid = cur.fetchone()[0]

        customer_id = random.randint(1, 5)
        cur.execute("""
            INSERT INTO APP_ORDER(ORDER_ID, CUSTOMER_ID, ORDER_TS, STATUS, NOTE)
            VALUES (:oid, :cid, SYSTIMESTAMP, 'NEW', 'generated')
        """, oid=oid, cid=customer_id)

        k = random.randint(1, 4)
        for _ in range(k):
            cur.execute("SELECT SEQ_ORDER_ITEM.NEXTVAL FROM dual")
            item_id = cur.fetchone()[0]
            product_id = random.randint(1, 5)
            qty = random.randint(1, 3)

            cur.execute("SELECT PRICE FROM APP_PRODUCT WHERE PRODUCT_ID=:pid", pid=product_id)
            unit_price = float(cur.fetchone()[0])

            cur.execute("""
                INSERT INTO APP_ORDER_ITEM(ORDER_ITEM_ID, ORDER_ID, PRODUCT_ID, QTY, UNIT_PRICE)
                VALUES (:iid, :oid, :pid, :qty, :price)
            """, iid=item_id, oid=oid, pid=product_id, qty=qty, price=unit_price)

        cur.execute("""
            INSERT INTO APP_JOB(ORDER_ID, STATUS)
            VALUES (:oid, 'QUEUED')
        """, oid=oid)

    conn.commit()

def worker_loop(conn):
    cur = conn.cursor()
    while True:
        order_id = cur.callfunc("PKG_BILLING.CLAIM_JOB", int, [WORKER])

        if not order_id or order_id == 0:
            time.sleep(2)
            continue

        try:
            cur.callproc("PKG_BILLING.SETTLE_ORDER", [order_id])
            cur.callproc("PKG_BILLING.COMPLETE_JOB", [order_id, 1, f"Settled by {WORKER}"])
        except Exception as e:
            cur.callproc("PKG_BILLING.COMPLETE_JOB", [order_id, 0, str(e)])
        conn.commit()

def main():
    time.sleep(5)
    with connect() as conn:
        seed(conn)
        create_orders_and_jobs(conn, n_orders=30)
        worker_loop(conn)

if __name__ == "__main__":
    main()
