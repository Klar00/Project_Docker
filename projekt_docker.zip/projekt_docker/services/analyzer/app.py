import os
import time
import datetime as dt
import oracledb
import pandas as pd
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore", message="pandas only supports SQLAlchemy")


DB_HOST = os.getenv("DB_HOST", "oracle")
DB_PORT = int(os.getenv("DB_PORT", "1521"))
DB_SERVICE = os.getenv("DB_SERVICE", "XEPDB1")
DB_USER = os.getenv("DB_USER", "APP")
DB_PASSWORD = os.getenv("DB_PASSWORD", "app_pass")
SNAPSHOT_SEC = int(os.getenv("SNAPSHOT_SEC", "30"))

ART_DIR = "/app/artifacts"
os.makedirs(ART_DIR, exist_ok=True)

def dsn():
    return oracledb.makedsn(DB_HOST, DB_PORT, service_name=DB_SERVICE)

def connect():
    return oracledb.connect(user=DB_USER, password=DB_PASSWORD, dsn=dsn())

def take_snapshot(conn):
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM APP_ORDER")
    orders_cnt = int(cur.fetchone()[0])

    cur.execute("SELECT NVL(SUM(GROSS_AMOUNT),0) FROM APP_INVOICE")
    revenue = float(cur.fetchone()[0])

    cur.execute("""
      SELECT p.SKU
      FROM APP_INVOICE_ITEM ii
      JOIN APP_PRODUCT p ON p.PRODUCT_ID = ii.PRODUCT_ID
      GROUP BY p.SKU
      ORDER BY SUM(ii.QTY) DESC
      FETCH FIRST 1 ROWS ONLY
    """)
    row = cur.fetchone()
    top_sku = row[0] if row else None

    cur.execute("SELECT COUNT(*) FROM APP_REJECTED_ROWS")
    bad_rows = int(cur.fetchone()[0])

    ts = dt.datetime.now()

    cur.execute("""
      MERGE INTO APP_METRICS m
      USING (SELECT :ts AS ts FROM dual) s
      ON (m.ts = s.ts)
      WHEN NOT MATCHED THEN
        INSERT (ts, orders_cnt, revenue_sum, top_sku, bad_rows)
        VALUES (:ts, :o, :r, :t, :b)
    """, ts=ts, o=orders_cnt, r=revenue, t=top_sku, b=bad_rows)

    conn.commit()

def export_artifacts(conn):
    df = pd.read_sql("""
      SELECT TS, ORDERS_CNT, REVENUE_SUM, TOP_SKU, BAD_ROWS
      FROM APP_METRICS
      ORDER BY TS
    """, con=conn)

    csv_path = os.path.join(ART_DIR, "metrics.csv")
    df.to_csv(csv_path, index=False)

    if not df.empty:
        plt.figure()
        plt.plot(pd.to_datetime(df["TS"]), df["REVENUE_SUM"])
        plt.xlabel("TS")
        plt.ylabel("REVENUE_SUM")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        png_path = os.path.join(ART_DIR, "revenue.png")
        plt.savefig(png_path)
        plt.close()

def main():
    time.sleep(5)
    with connect() as conn:
        while True:
            take_snapshot(conn)
            export_artifacts(conn)
            time.sleep(SNAPSHOT_SEC)

if __name__ == "__main__":
    main()
